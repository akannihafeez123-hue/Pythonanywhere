
# aggregator.py - multi-timeframe orchestration and final decision
import os
from ai_brain import load_meta_model, meta_predict_from_raw_windows

META_MODEL_PATH = os.environ.get('META_MODEL_PATH','model/meta_model.h5')
CONF_THRESHOLD = float(os.environ.get('CONF_THRESHOLD','0.85'))

MODEL, SCALER, PLATT = load_meta_model(META_MODEL_PATH)

def build_windows_for_timeframes(df_per_tf, window_sizes_per_tf):
    windows = []
    for tf, df in df_per_tf.items():
        n = window_sizes_per_tf.get(tf, 32)
        if len(df) < n:
            windows.append(df.copy())
        else:
            windows.append(df.tail(n).copy())
    return windows

def evaluate_confluence(df_per_tf, chosen_expiry_bars, window_sizes_per_tf=None):
    if window_sizes_per_tf is None:
        window_sizes_per_tf = {k: 32 for k in df_per_tf.keys()}
    windows = build_windows_for_timeframes(df_per_tf, window_sizes_per_tf)
    out = meta_predict_from_raw_windows(windows, MODEL, SCALER, PLATT)
    buy_prob = out['buy_prob']
    sell_prob = out['sell_prob']
    direction = 'BUY' if buy_prob > sell_prob else 'SELL'
    confidence = max(buy_prob, sell_prob)
    final_decision = direction if confidence >= CONF_THRESHOLD else 'NO_TRADE'
    return {'buy_prob': buy_prob, 'sell_prob': sell_prob, 'final_decision': final_decision, 'confidence': confidence, 'debug': out}
