
# ai_brain.py - meta-model interface (train on Colab, run inference here)
import numpy as np
import pickle, os
from tensorflow import keras
from strategies import engine_vector_for

def load_meta_model(path='model/meta_model.h5'):
    model = None
    scaler = None
    platt = None
    if os.path.exists(path):
        model = keras.models.load_model(path)
    scl = path + '.scaler.pkl'
    if os.path.exists(scl):
        with open(scl,'rb') as f:
            scaler = pickle.load(f)
    pl = path + '.platt.pkl'
    if os.path.exists(pl):
        with open(pl,'rb') as f:
            platt = pickle.load(f)
    return model, scaler, platt

def meta_predict_from_raw_windows(windows, model, scaler, platt=None):
    X = []
    raws = []
    for w in windows:
        engs = ['Fibonacci','Quantum','DarkPool','Gann','Elliott','Cosmic']
        scs = []
        rawd = {}
        for e in engs:
            s, r = engine_vector_for(w, e)
            scs.append(s)
            rawd[e] = r
        X.append(scs)
        raws.append(rawd)
    X = np.array(X)
    if scaler is not None:
        try:
            Xs = scaler.transform(X)
        except Exception:
            Xs = X
    else:
        Xs = X
    if model is None:
        buy_prob = float(np.mean(Xs))
        sell_prob = 1.0 - buy_prob
    else:
        out = model.predict(Xs, verbose=0)
        if isinstance(out, list) and len(out) == 2:
            buy_prob = float(np.mean(out[0]))
            sell_prob = float(np.mean(out[1]))
        else:
            buy_prob = float(np.mean(out))
            sell_prob = 1.0 - buy_prob
    if platt is not None:
        try:
            import numpy as _np
            buy_prob = float(platt.predict_proba(_np.array(buy_prob).reshape(-1,1))[0,1])
            sell_prob = float(platt.predict_proba(_np.array(sell_prob).reshape(-1,1))[0,1])
        except Exception:
            pass
    return {'buy_prob': buy_prob, 'sell_prob': sell_prob, 'raws': raws}
