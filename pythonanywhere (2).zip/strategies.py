
# strategies.py - feature extractors for hidden strategies
import numpy as np
import pandas as pd
from scipy.signal import periodogram

def add_basic_tech(df):
    import ta
    df = df.copy()
    df['rsi'] = ta.momentum.RSIIndicator(df['close'], window=14).rsi().fillna(0)
    df['ema8'] = ta.trend.EMAIndicator(df['close'], window=8).ema_indicator().fillna(0)
    df['ema21'] = ta.trend.EMAIndicator(df['close'], window=21).ema_indicator().fillna(0)
    df['atr'] = ta.volatility.AverageTrueRange(df['high'], df['low'], df['close'], window=14).average_true_range().fillna(0)
    df['volume'] = df['volume'].fillna(0)
    return df.fillna(method='ffill').fillna(0)

def fib_vortex_features(df, lookback=50):
    df = df.copy()
    highs = df['high'].rolling(lookback).max()
    lows = df['low'].rolling(lookback).min()
    diff = highs - lows + 1e-9
    for r in [0.236, 0.382, 0.618]:
        df[f'fib_{r}'] = (df['close'] - (highs - diff*r)) / diff
    import ta
    df['vi_pos'] = ta.trend.vortex_indicator_pos(df['high'], df['low'], df['close'], window=14).fillna(0)
    df['vi_neg'] = ta.trend.vortex_indicator_neg(df['high'], df['low'], df['close'], window=14).fillna(0)
    return df.fillna(0)

def quantum_features(df):
    df = df.copy()
    close = df['close'].values.astype(float)
    if len(close) >= 128:
        freqs, psd = periodogram(close - np.mean(close))
        low_band = (freqs > 0) & (freqs < 0.02)
        df['q_spec_low'] = float(np.sum(psd[low_band]) / (np.sum(psd)+1e-12))
    else:
        df['q_spec_low'] = 0.0
    df['q_cross_tf_corr'] = df['close'].rolling(5).corr(df['close'].rolling(20).mean()).fillna(0)
    return df.fillna(0)

def dark_pool_features(df):
    df = df.copy()
    df['vol_median'] = df['volume'].rolling(50).median().fillna(1)
    df['vol_spike'] = (df['volume'] - df['vol_median']) / (df['vol_median'] + 1e-9)
    df['dir_vol'] = (df['close'] - df['open']) * df['volume']
    df['dir_vol_sma'] = df['dir_vol'].rolling(50).mean().fillna(0)
    return df.fillna(0)

def gann_features(df):
    df = df.copy()
    close = df['close'].fillna(method='ffill').values
    if len(close) >= 128:
        freqs, psd = periodogram(close - np.mean(close))
        low_band = (freqs > 0) & (freqs < 0.02)
        df['gann_cycle_strength'] = float(np.sum(psd[low_band]) / (np.sum(psd)+1e-12))
    else:
        df['gann_cycle_strength'] = 0.0
    return df.fillna(0)

def elliott_features(df):
    df = df.copy()
    from scipy.signal import argrelextrema
    close = df['close'].values
    if len(close) < 10:
        df['wave_count'] = 0
        return df
    max_idx = argrelextrema(close, np.greater, order=3)[0]
    min_idx = argrelextrema(close, np.less, order=3)[0]
    df['wave_count'] = 0
    df.loc[df.index.isin(max_idx), 'wave_count'] = 1
    df.loc[df.index.isin(min_idx), 'wave_count'] = -1
    df['wave_count'] = df['wave_count'].rolling(20).sum().fillna(0)
    return df.fillna(0)

def cosmic_features(df):
    df = df.copy()
    df['date'] = pd.to_datetime(df['timestamp'])
    epoch = pd.Timestamp('2000-01-06')
    df['days_from_epoch'] = (df['date'] - epoch).dt.total_seconds() / 86400.0
    df['lunar_phase'] = (df['days_from_epoch'] % 29.53) / 29.53
    return df.fillna(0)

def engine_vector_for(df, engine_name):
    df = add_basic_tech(df)
    if engine_name == 'Fibonacci':
        df2 = fib_vortex_features(df)
        vals = {
            'fib_0236': df2['fib_0.236'].iloc[-3:].mean() if 'fib_0.236' in df2.columns else 0.0,
            'fib_0382': df2['fib_0.382'].iloc[-3:].mean() if 'fib_0.382' in df2.columns else 0.0,
            'fib_0618': df2['fib_0.618'].iloc[-3:].mean() if 'fib_0.618' in df2.columns else 0.0,
            'vi_pos': df2['vi_pos'].iloc[-1] if 'vi_pos' in df2.columns else 0.0,
            'vi_neg': df2['vi_neg'].iloc[-1] if 'vi_neg' in df2.columns else 0.0,
        }
    elif engine_name == 'Quantum':
        df2 = quantum_features(df)
        vals = {'q_spec_low': df2['q_spec_low'].iloc[-1] if 'q_spec_low' in df2.columns else 0.0, 'q_cross_tf_corr': df2['q_cross_tf_corr'].iloc[-1] if 'q_cross_tf_corr' in df2.columns else 0.0}
    elif engine_name == 'DarkPool':
        df2 = dark_pool_features(df)
        vals = {'vol_spike': df2['vol_spike'].iloc[-1] if 'vol_spike' in df2.columns else 0.0, 'dir_vol_sma': df2['dir_vol_sma'].iloc[-1] if 'dir_vol_sma' in df2.columns else 0.0}
    elif engine_name == 'Gann':
        df2 = gann_features(df)
        vals = {'gann_cycle_strength': df2['gann_cycle_strength'].iloc[-1] if 'gann_cycle_strength' in df2.columns else 0.0}
    elif engine_name == 'Elliott':
        df2 = elliott_features(df)
        vals = {'wave_count': df2['wave_count'].iloc[-1] if 'wave_count' in df2.columns else 0.0}
    elif engine_name == 'Cosmic':
        df2 = cosmic_features(df)
        vals = {'lunar_phase': df2['lunar_phase'].iloc[-1] if 'lunar_phase' in df2.columns else 0.0}
    else:
        vals = {}
    arr = np.array(list(vals.values())) if len(vals)>0 else np.array([0.0])
    def norm(x):
        x = max(min(x, 1e6), -1e6)
        try:
            return 1.0/(1.0+np.exp(-x))
        except:
            return 0.5
    vec = np.array([norm(float(x)) for x in arr])
    return float(np.mean(vec)), vals
