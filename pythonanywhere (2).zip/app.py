
# app.py - Telegram command handler for decision-only AI bot
import os, pandas as pd, logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from aggregator import evaluate_confluence

logging.basicConfig(level=logging.INFO)
TELEGRAM_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN','')
ADMIN_ID = int(os.environ.get('TELEGRAM_ADMIN_ID','0'))
DATA_FOLDER = os.environ.get('DATA_FOLDER','data')

def load_symbol_csv(symbol, tf_label):
    path = os.path.join(DATA_FOLDER, f"{symbol}_{tf_label}.csv")
    if not os.path.exists(path):
        raise FileNotFoundError(f"CSV not found: {path}")
    df = pd.read_csv(path)
    if 'timestamp' in df.columns:
        try:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
        except:
            pass
    return df.sort_values('timestamp').reset_index(drop=True)

async def analyze_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id != ADMIN_ID:
        await update.message.reply_text("Unauthorized.")
        return
    args = context.args
    if len(args) < 3:
        await update.message.reply_text("Usage: /analyze <SYMBOL> <BASE_TF_label eg 1m> <EXPIRY_BARS>\nExample: /analyze BTCUSDT 1m 5")
        return
    symbol = args[0].upper()
    base_tf = args[1]
    expiry_bars = int(args[2])
    tfs = [base_tf, '5m', '15m', '1h']
    df_per_tf = {}
    try:
        for tf in tfs:
            df_per_tf[tf] = load_symbol_csv(symbol, tf)
    except Exception as e:
        await update.message.reply_text(f"Error loading data: {e}")
        return
    res = evaluate_confluence(df_per_tf, chosen_expiry_bars=expiry_bars)
    final = res['final_decision']
    conf = res['confidence']
    buyp = res['buy_prob']
    sellp = res['sell_prob']
    lines = []
    lines.append("⚛️ AI DECISION: {}".format(final if final!='NO_TRADE' else 'NO TRADE'))
    lines.append("📈 Confidence: {0:.2%}".format(conf))
    lines.append("🧠 Alignment: ") 
    debug = res.get('debug',{})
    raws = debug.get('raws',[])
    if raws and isinstance(raws, list) and len(raws)>0:
        first = raws[0]
        if isinstance(first, dict):
            engine_names = list(first.keys())
            lines.append(', '.join(engine_names))
    lines.append("⏱ Timeframes analyzed: {}".format(','.join(list(df_per_tf.keys()))))
    lines.append("") 
    lines.append("Details:")
    lines.append(f"raw buy_prob: {buyp:.4f}, raw sell_prob: {sellp:.4f}")
    if final == 'NO_TRADE':
        lines.append("Note: confidence below threshold ({}) — NO TRADE.".format(os.environ.get('CONF_THRESHOLD','0.85')))
    await update.message.reply_text('\n'.join(lines))

def run_bot():
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()
    app.add_handler(CommandHandler('analyze', analyze_command))
    print('Bot started - use /analyze SYMBOL TF EXPIRY_BARS')
    app.run_polling()

if __name__ == '__main__':
    run_bot()
