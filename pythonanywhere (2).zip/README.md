PythonAnywhere AI Decision Bot - Mobile-ready package

Quick start (phone-friendly):
1. Upload pythonanywhere.zip in PythonAnywhere > Files and extract.
2. Open the folder 'pythonanywhere' and edit '.env.template':
   - Set TELEGRAM_BOT_TOKEN to your bot token
   - Set TELEGRAM_ADMIN_ID to your Telegram user id
   - Set DATA_FOLDER to /home/yourusername/pythonanywhere/data
   - Set META_MODEL_PATH to /home/yourusername/pythonanywhere/model/meta_model.h5
   - Set CONF_THRESHOLD to 0.85 (or 0.80-0.90)
3. Upload your model file meta_model.h5 to the model/ folder (optional - without it bot returns NO_TRADE)
4. Upload CSV data files into data/ named like SYMBOL_1m.csv, SYMBOL_5m.csv, SYMBOL_15m.csv, SYMBOL_1h.csv
   e.g., BTCUSDT_1m.csv or EURUSD_1m.csv
5. On PythonAnywhere > Web: Add new web app (Manual -> Python 3.10).
   Set source folder to /home/yourusername/pythonanywhere
6. Edit WSGI file: add this line (adjust username):
   import sys
   sys.path.append('/home/yourusername/pythonanywhere')
   from app import app as application
7. Set environment variables (optional) in Account > Environment variables, or copy .env.template to .env.
8. Reload the web app. Use your Telegram bot and send:
   /analyze <SYMBOL> <BASE_TF_label> <EXPIRY_BARS>
   Example: /analyze BTCUSDT 1m 5
   The bot is decision-only; it will reply with a long-format detailed message.

Notes:
- This package is decision-only (no Pocket Option auth/autotrade).
- Train meta-model (meta_model.h5) offline (Colab recommended) and upload for best results.
- The bot supports both crypto (e.g., BTCUSDT) and forex (e.g., EURUSD) symbol CSVs.
